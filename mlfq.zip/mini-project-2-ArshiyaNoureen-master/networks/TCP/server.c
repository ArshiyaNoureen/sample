#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080

char board[3][3];
int currentPlayer = 1;  // 1 for Player 1, 2 for Player 2

void initialize_board() {
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            board[i][j] = ' ';
}

int check_winner() {
    for (int i = 0; i < 3; i++) {
        if (board[i][0] == board[i][1] && board[i][1] == board[i][2] && board[i][0] != ' ') return currentPlayer;
        if (board[0][i] == board[1][i] && board[1][i] == board[2][i] && board[0][i] != ' ') return currentPlayer;
    }
    if (board[0][0] == board[1][1] && board[1][1] == board[2][2] && board[0][0] != ' ') return currentPlayer;
    if (board[0][2] == board[1][1] && board[1][1] == board[2][0] && board[0][2] != ' ') return currentPlayer;
    return 0;
}

int is_draw() {
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            if (board[i][j] == ' ') return 0;
    return 1;
}

void send_board(int client_socket) {
    char board_str[200];
    sprintf(board_str, "\n ___________\n");
    for (int i = 0; i < 3; i++) {
        strcat(board_str, "| ");
        for (int j = 0; j < 3; j++) {
            if (board[i][j] == 'X')
                strcat(board_str, "X | ");
            else if (board[i][j] == 'O')
                strcat(board_str, "O | ");
            else
                strcat(board_str, "  | ");
        }
        strcat(board_str, "\n|___|___|___|\n");
    }
    strcat(board_str, "\n");
    send(client_socket, board_str, strlen(board_str), 0);
}

void play_game(int client_socket1, int client_socket2) {
    int row, col, winner;
    char buffer[1024];

    while (1) {
        int current_client = (currentPlayer == 1) ? client_socket1 : client_socket2;
        sprintf(buffer, "Your turn Player %s. Enter row (0-2) and column (0-2): ", (currentPlayer == 1) ? "X" : "O");
        send(current_client, buffer, strlen(buffer), 0);

        read(current_client, buffer, 1024);
        sscanf(buffer, "%d %d", &row, &col);

        if (row < 0 || row > 2 || col < 0 || col > 2 || board[row][col] != ' ') {
            sprintf(buffer, "Invalid move, try again.\n");
            send(current_client, buffer, strlen(buffer), 0);
            continue;
        }

        board[row][col] = (currentPlayer == 1) ? 'X' : 'O';
        send_board(client_socket1);
        send_board(client_socket2);

        winner = check_winner();
        if (winner) {
            sprintf(buffer, "Player %d wins!\n", currentPlayer);
            send(client_socket1, buffer, strlen(buffer), 0);
            send(client_socket2, buffer, strlen(buffer), 0);
            break;
        }

        if (is_draw()) {
            sprintf(buffer, "It's a draw!\n");
            send(client_socket1, buffer, strlen(buffer), 0);
            send(client_socket2, buffer, strlen(buffer), 0);
            break;
        }

        currentPlayer = (currentPlayer == 1) ? 2 : 1;
    }
}

int play_again(int client_socket1, int client_socket2) {
    char buffer1[1024], buffer2[1024];
    memset(buffer1, 0, sizeof(buffer1));
    memset(buffer2, 0, sizeof(buffer2));
    read(client_socket1, buffer1, 1024);
    read(client_socket2, buffer2, 1024);
    // Debug prints to verify received data
    printf("Player 1 response: %s\n", buffer1);
    printf("Player 2 response: %s\n", buffer2);

    // If both players say yes
    if (strncmp(buffer1, "yes", 3) == 0 && strncmp(buffer2, "yes", 3) == 0) {
        sprintf(buffer1, "Starting new game.\n");
        send(client_socket1, buffer1, strlen(buffer1), 0);
        send(client_socket2, buffer1, strlen(buffer1), 0);
        return 1; // Start a new game
    }

    // If both players say no
    if (strncmp(buffer1, "no", 2) == 0 && strncmp(buffer2, "no", 2) == 0) {
        sprintf(buffer1, "Closing connection.\n");
        send(client_socket1, buffer1, strlen(buffer1), 0);
        send(client_socket2, buffer1, strlen(buffer1), 0);
        return 0; // Close the connection
    }

    // If one says yes and the other says no
    if (strncmp(buffer1, "yes", 3) == 0 && strncmp(buffer2, "no", 2) == 0) {
        sprintf(buffer1, "Your opponent does not want to play again. Closing connection.\n");
        send(client_socket1, buffer1, strlen(buffer1), 0);
        send(client_socket2, buffer1, strlen(buffer1), 0);
    } else if (strncmp(buffer1, "no", 2) == 0 && strncmp(buffer2, "yes", 3) == 0) {
        sprintf(buffer2, "Your opponent does not want to play again. Closing connection.\n");
        send(client_socket1, buffer2, strlen(buffer2), 0);
        send(client_socket2, buffer2, strlen(buffer2), 0);
    }

    return 0; // Close the connection
}

int main() {
    int server_fd, client_socket1, client_socket2;
    struct sockaddr_in address;
    int addrlen = sizeof(address);

    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd == 0) {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }

    if (listen(server_fd, 3) < 0) {
        perror("listen");
        exit(EXIT_FAILURE);
    }

    printf("Waiting for players to join...\n");
    client_socket1 = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen);
    printf("Player 1 connected.\n");

    client_socket2 = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen);
    printf("Player 2 connected.\n");

    while (1) {
        initialize_board();
        currentPlayer = 1;   // Reset the current player to Player 1
        play_game(client_socket1, client_socket2);

        if (!play_again(client_socket1, client_socket2)) {
            break;
        }
    }

    close(client_socket1);
    close(client_socket2);
    close(server_fd);

    return 0;
}
