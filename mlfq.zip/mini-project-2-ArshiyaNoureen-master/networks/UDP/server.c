#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define MAX_CLIENTS 2

char board[3][3];
int currentPlayer = 1; // 1 for Player 1, 2 for Player 2

void initialize_board() {
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            board[i][j] = ' ';
}

int check_winner() {
    for (int i = 0; i < 3; i++) {
        if (board[i][0] == board[i][1] && board[i][1] == board[i][2] && board[i][0] != ' ') 
            return currentPlayer;
        if (board[0][i] == board[1][i] && board[1][i] == board[2][i] && board[0][i] != ' ') 
            return currentPlayer;
    }
    if (board[0][0] == board[1][1] && board[1][1] == board[2][2] && board[0][0] != ' ') 
        return currentPlayer;
    if (board[0][2] == board[1][1] && board[1][1] == board[2][0] && board[0][2] != ' ') 
        return currentPlayer;
    return 0;
}

int is_draw() {
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            if (board[i][j] == ' ') return 0;
    return 1;
}

void send_board(int client_socket, struct sockaddr_in *client_addr1, struct sockaddr_in *client_addr2) {
    char board_str[200];
    memset(board_str, 0, sizeof(board_str)); // Clear the buffer before use
    sprintf(board_str, "\n ___________\n");
    for (int i = 0; i < 3; i++) {
        strcat(board_str, "| ");
        for (int j = 0; j < 3; j++) {
            if (board[i][j] == 'X')
                strcat(board_str, "X | ");
            else if (board[i][j] == 'O')
                strcat(board_str, "O | ");
            else
                strcat(board_str, "  | ");
        }
        strcat(board_str, "\n|___|___|___|\n");
    }
    strcat(board_str, "\n");
    sendto(client_socket, board_str, strlen(board_str), 0, (struct sockaddr*)client_addr1, sizeof(*client_addr1));
    sendto(client_socket, board_str, strlen(board_str), 0, (struct sockaddr*)client_addr2, sizeof(*client_addr2));
}

void play_game(int client_socket, struct sockaddr_in *client_addr1, struct sockaddr_in *client_addr2) {
    int row, col, winner;
    char buffer[1024];
    socklen_t addr_len;

    while (1) {
        struct sockaddr_in current_addr = (currentPlayer == 1) ? *client_addr1 : *client_addr2;
        sprintf(buffer, "Your turn Player %s. Enter row (0-2) and column (0-2): ", (currentPlayer == 1) ? "X" : "O");
        sendto(client_socket, buffer, strlen(buffer), 0, (struct sockaddr*)&current_addr, sizeof(current_addr));

        addr_len = sizeof(current_addr);
        memset(buffer, 0, sizeof(buffer)); // Clear buffer before receiving input
        recvfrom(client_socket, buffer, 1024, 0, (struct sockaddr*)&current_addr, &addr_len);
        sscanf(buffer, "%d %d", &row, &col);

        if (row < 0 || row > 2 || col < 0 || col > 2 || board[row][col] != ' ') {
            sprintf(buffer, "Invalid move, try again.\n");
            sendto(client_socket, buffer, strlen(buffer), 0, (struct sockaddr*)&current_addr, sizeof(current_addr));
            continue;
        }

        board[row][col] = (currentPlayer == 1) ? 'X' : 'O';
        send_board(client_socket, client_addr1, client_addr2);

        winner = check_winner();
        if (winner) {
            sprintf(buffer, "Player %d wins!\n", currentPlayer);
            sendto(client_socket, buffer, strlen(buffer), 0, (struct sockaddr*)client_addr1, sizeof(*client_addr1));
            sendto(client_socket, buffer, strlen(buffer), 0, (struct sockaddr*)client_addr2, sizeof(*client_addr2));
            break;
        }

        if (is_draw()) {
            sprintf(buffer, "It's a draw!\n");
            sendto(client_socket, buffer, strlen(buffer), 0, (struct sockaddr*)client_addr1, sizeof(*client_addr1));
            sendto(client_socket, buffer, strlen(buffer), 0, (struct sockaddr*)client_addr2, sizeof(*client_addr2));
            break;
        }

        currentPlayer = (currentPlayer == 1) ? 2 : 1;
    }
}

int play_again(int client_socket, struct sockaddr_in *client_addr1, struct sockaddr_in *client_addr2) {
    char buffer1[1024], buffer2[1024];
    socklen_t addr_len;

    memset(buffer1, 0, sizeof(buffer1)); // Clear buffer1 before receiving input
    memset(buffer2, 0, sizeof(buffer2)); // Clear buffer2 before receiving input

    // Receive responses from both players
    addr_len = sizeof(*client_addr1);
    recvfrom(client_socket, buffer1, 1024, 0, (struct sockaddr*)client_addr1, &addr_len);
    addr_len = sizeof(*client_addr2);
    recvfrom(client_socket, buffer2, 1024, 0, (struct sockaddr*)client_addr2, &addr_len);

    // Debug prints to verify received data
    printf("Player 1 response: %s\n", buffer1);
    printf("Player 2 response: %s\n", buffer2);

    // If both players say yes
    if (strncmp(buffer1, "yes", 3) == 0 && strncmp(buffer2, "yes", 3) == 0) {
        memset(buffer1, 0, sizeof(buffer1)); // Clear buffer1 before receiving input
        sprintf(buffer1, "Starting new game.\n");
        sendto(client_socket, buffer1, strlen(buffer1), 0, (struct sockaddr*)client_addr1, sizeof(*client_addr1));
        sendto(client_socket, buffer1, strlen(buffer1), 0, (struct sockaddr*)client_addr2, sizeof(*client_addr2));
        return 1; // Start a new game
    }

    // If both players say no
    if (strncmp(buffer1, "no", 2) == 0 && strncmp(buffer2, "no", 2) == 0) {
        memset(buffer1, 0, sizeof(buffer1)); // Clear buffer1 before receiving input

        sprintf(buffer1, "Closing connection.\n");
        sendto(client_socket, buffer1, strlen(buffer1), 0, (struct sockaddr*)client_addr1, sizeof(*client_addr1));
        sendto(client_socket, buffer1, strlen(buffer1), 0, (struct sockaddr*)client_addr2, sizeof(*client_addr2));
        return 0; // Close the connection
    }

    // If one says yes and the other says no
    if (strncmp(buffer1, "yes", 3) == 0 && strncmp(buffer2, "no", 2) == 0) {
        memset(buffer1, 0, sizeof(buffer1)); // Clear buffer1 before receiving input
        sprintf(buffer1, "Your opponent does not want to play again. Closing connection.\n");
        sendto(client_socket, buffer1, strlen(buffer1), 0, (struct sockaddr*)client_addr1, sizeof(*client_addr1));
        sendto(client_socket, buffer1, strlen(buffer1), 0, (struct sockaddr*)client_addr2, sizeof(*client_addr2));
    } else if (strncmp(buffer1, "no", 2) == 0 && strncmp(buffer2, "yes", 3) == 0) {
        memset(buffer1, 0, sizeof(buffer1)); // Clear buffer1 before receiving input
        sprintf(buffer2, "Your opponent does not want to play again. Closing connection.\n");
        sendto(client_socket, buffer2, strlen(buffer2), 0, (struct sockaddr*)client_addr1, sizeof(*client_addr1));
        sendto(client_socket, buffer2, strlen(buffer2), 0, (struct sockaddr*)client_addr2, sizeof(*client_addr2));
    }

    return 0; // Close the connection
}

int main() {
    int server_fd;
    struct sockaddr_in address, client_addr1, client_addr2;
    socklen_t addr_len = sizeof(address);

    server_fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (server_fd < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    if (bind(server_fd, (struct sockaddr*)&address, sizeof(address)) < 0) {
        perror("Bind failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    printf("Waiting for players to join...\n");

    // Accept two clients
    recvfrom(server_fd, NULL, 0, 0, (struct sockaddr*)&client_addr1, &addr_len);
    printf("Player 1 joined.\n");
    recvfrom(server_fd, NULL, 0, 0, (struct sockaddr*)&client_addr2, &addr_len);
    printf("Player 2 joined.\n");

    initialize_board();
    send_board(server_fd, &client_addr1, &client_addr2);

    while (1) {
        play_game(server_fd, &client_addr1, &client_addr2);
        char response[1024];

        if (!play_again(server_fd, &client_addr1, &client_addr2)) break;

        initialize_board();
        currentPlayer = 1; // Reset to Player 1
        send_board(server_fd, &client_addr1, &client_addr2);
    }

    close(server_fd);
    return 0;
}
