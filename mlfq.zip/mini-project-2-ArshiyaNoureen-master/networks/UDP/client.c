#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define SERVER_IP "127.0.0.1" // Change this to the server's IP if running on a different machine

int main() {
    int client_socket;
    struct sockaddr_in server_addr;
    char buffer[1024];
    int row, col;

    // Create a UDP socket
    client_socket = socket(AF_INET, SOCK_DGRAM, 0);
    if (client_socket < 0) {
        perror("socket creation failed");
        exit(EXIT_FAILURE);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    inet_pton(AF_INET, SERVER_IP, &server_addr.sin_addr);

    // Notify the server of connection
    sendto(client_socket, NULL, 0, 0, (struct sockaddr*)&server_addr, sizeof(server_addr));

    while (1) {
        // Clear the buffer before receiving the board state
        memset(buffer, 0, sizeof(buffer));
        
        // Receive board state and prompt from the server
        recvfrom(client_socket, buffer, sizeof(buffer), 0, NULL, NULL);
        printf("%s", buffer);

        // Check if it's this player's turn
        if (strstr(buffer, "Your turn")) {
            // Get user input for the next move
            printf("Enter your move (row and column): ");
            scanf("%d %d", &row, &col);
            sprintf(buffer, "%d %d", row, col);

            // Send the move to the server
            sendto(client_socket, buffer, strlen(buffer), 0, (struct sockaddr*)&server_addr, sizeof(server_addr));

            // Clear the buffer before receiving the next message
            memset(buffer, 0, sizeof(buffer));

            // Wait for the next prompt from the server
            recvfrom(client_socket, buffer, sizeof(buffer), 0, NULL, NULL);
            printf("%s", buffer);

        }
         // Check if the game is over
            if (strstr(buffer, "wins!") || strstr(buffer, "draw")) {
                
                // Ask if players want to play again
                char response[10];
                printf("Do you want to play again? (yes/no): ");
                scanf("%s", response);
                sendto(client_socket, response, strlen(response), 0, (struct sockaddr*)&server_addr, sizeof(server_addr));
                
                // Clear the buffer before checking the closing message
                memset(buffer, 0, sizeof(buffer));
                recvfrom(client_socket, buffer, sizeof(buffer), 0, NULL, NULL);
                if (strstr(buffer, "Closing connection") != NULL) {
                    printf("Game over. Connection will be closed.\n");
                    break;
                }
                else{
                    printf("%s\n",buffer);
                }
            }
    }

    close(client_socket);
    return 0;
}
