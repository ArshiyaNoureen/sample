#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <unistd.h>

#define PORT 8080
#define CHUNK_SIZE 1024
#define MAX_CHUNKS 10

// Structure to represent a data chunk
typedef struct {
    int seq_no;
    int total_chunks;
    char data[CHUNK_SIZE];
} DataChunk;

void error(const char *msg) {
    perror(msg);
    exit(1);
}

void receive_chunks(int sockfd, struct sockaddr_in *client_addr, socklen_t *addr_len) {
    DataChunk chunk;
    char buffer[CHUNK_SIZE * MAX_CHUNKS] = {0};
    int received_chunks[MAX_CHUNKS] = {0};
    int total_chunks = 0;

    while (1) {
        if (recvfrom(sockfd, &chunk, sizeof(chunk), 0, (struct sockaddr *)client_addr, addr_len) < 0) {
            error("Failed to receive data");
        }

        printf("Received chunk %d/%d: %s\n", chunk.seq_no + 1, chunk.total_chunks, chunk.data);

        if (!received_chunks[chunk.seq_no]) {
            memcpy(buffer + chunk.seq_no * CHUNK_SIZE, chunk.data, CHUNK_SIZE);
            received_chunks[chunk.seq_no] = 1;
            if (chunk.total_chunks > total_chunks) {
                total_chunks = chunk.total_chunks;
            }
        }

        // If all chunks received, assemble the message
        int all_received = 1;
        for (int i = 0; i < total_chunks; i++) {
            if (!received_chunks[i]) {
                all_received = 0;
                break;
            }
        }

        if (all_received) {
            printf("\nAll chunks received. Full message:\n%s\n", buffer);
            break;
        }
    }
}

void send_data_chunks(int sockfd, struct sockaddr_in *client_addr, socklen_t addr_len, char *message) {
    int total_chunks = (strlen(message) + CHUNK_SIZE - 1) / CHUNK_SIZE; // Calculate total chunks
    DataChunk chunk;

    for (int i = 0; i < total_chunks; i++) {
        chunk.seq_no = i;
        chunk.total_chunks = total_chunks;
        strncpy(chunk.data, message + i * CHUNK_SIZE, CHUNK_SIZE);

        if (sendto(sockfd, &chunk, sizeof(chunk), 0, (struct sockaddr *)client_addr, addr_len) < 0) {
            error("Failed to send data");
        }

        printf("Sent chunk %d/%d: %s\n", chunk.seq_no + 1, chunk.total_chunks, chunk.data);
    }
}

int main() {
    int sockfd;
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_len = sizeof(client_addr);
    char message[CHUNK_SIZE * MAX_CHUNKS];
    
    // Create UDP socket
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        error("Socket creation failed");
    }

    memset(&server_addr, 0, sizeof(server_addr));
    memset(&client_addr, 0, sizeof(client_addr));

    // Bind the socket to the port
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    if (bind(sockfd, (const struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        error("Bind failed");
    }

    printf("Server listening on port %d...\n", PORT);

    // Infinite loop to send and receive messages
    while (1) {
        printf("\nWaiting to receive a message...\n");
        receive_chunks(sockfd, &client_addr, &addr_len);

        printf("\nEnter message to send: ");
        fgets(message, sizeof(message), stdin);
        message[strcspn(message, "\n")] = 0;  // Remove newline character

        send_data_chunks(sockfd, &client_addr, addr_len, message);
    }

    close(sockfd);
    return 0;
}
