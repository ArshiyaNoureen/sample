
#ifndef QUEUE_H
#define QUEUE_H

// Time slices for priorities 0, 1, 2, and 3
extern int time_slice[4];

// Global queues for each priority level
extern struct proc *queues[4];

// Function declarations
void enqueue(int priority, struct proc *process);
struct proc* dequeue(int priority);
void push_to_lower_queue(struct proc *process);
void priority_boosting();
struct proc* create_process(int pid);
void display_queues();

#endif 