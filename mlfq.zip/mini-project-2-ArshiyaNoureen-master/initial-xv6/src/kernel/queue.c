#include <stdio.h>
#include <stdlib.h>
#include "proc.h"

// Global queues for each priority level
struct proc *queues[4] = {NULL, NULL, NULL, NULL};
int time_slice[4] = {1, 4, 50000, 16}; // Time slices for priorities 0, 1, 2, and 3

// Enqueue process into the appropriate priority queue
void enqueue(int priority, struct proc *process) {
    if (priority < 0 || priority > 3) {
        printf("Invalid priority!\n");
        return;
    }
    process->mlfq_priority = priority;
    process->next = NULL;
    struct proc *head = queues[priority];
    
    if (head == NULL) {
        queues[priority] = process;
    } else {
        while (head->next != NULL)
            head = head->next;
        head->next = process;
    }
}

// Dequeue process from the head of the queue with given priority
struct proc* dequeue(int priority) {
    if (priority < 0 || priority > 3) {
        printf("Invalid priority!\n");
        return NULL;
    }
    struct proc *head = queues[priority];
    if (head == NULL) {
        printf("Queue is empty for priority %d\n", priority);
        return NULL;
    }
    queues[priority] = head->next;
    head->next = NULL;
    return head;
}

// Move process to the next lower priority queue
void push_to_lower_queue(struct proc *process) {
    if (process->mlfq_priority < 3) { // If not at the lowest priority queue
        enqueue(process->mlfq_priority + 1, process);
        printf("Process %d moved to lower queue %d\n", process->pid, process->priority + 1);
    } else {
        enqueue(3, process); // Keep it in the lowest queue
        printf("Process %d remains in the lowest queue\n", process->pid);
    }
}

// Boost all processes back to the highest priority
void priority_boosting() {
    for (int i = 1; i <= 3; i++) { // Start from lower priorities
        struct proc *current = queues[i];
        while (current != NULL) {
            struct proc *next = current->next;
            enqueue(0, current); // Move to highest priority
            current = next;
        }
        queues[i] = NULL; // Clear the lower queue
    }
    printf("Priority boosting done. All processes moved to the highest priority queue.\n");
}

// Function to create a new process
struct proc* create_process(int pid) {
    struct proc *new_process = (struct proc*)malloc(sizeof(struct proc));
    new_process->pid = pid;
    new_process->mlfq_priority = 0;
    new_process->next = NULL;
    return new_process;
}

// Display the state of all queues
void display_queues() {
    for (int i = 0; i < 4; i++) {
        printf("Queue %d: ", i);
        struct proc *current = queues[i];
        if (current == NULL) {
            printf("Empty\n");
        } else {
            while (current != NULL) {
                printf("P%d -> ", current->pid);
                current = current->next;
            }
            printf("NULL\n");
        }
    }
}
