#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/syscall.h"

// Array of syscall names corresponding to their syscall numbers
const char *syscall_names[] = { 
    "fork",
    "exit",
    "wait",
    "pipe",
    "read",
    "kill",
    "exec",
    "fstat",
    "chdir",
    "dup",
    "getpid",
    "sbrk",
    "sleep",
    "uptime",
    "open",
    "write",
    "mknod",
    "unlink",
    "link",
    "mkdir",
    "close",
    "waitx",
    "sigalarm",
    "sigreturn",
    "getSysCount"
};

int find_syscall_index(int mask) {
    int result = 0;
    while (mask > 1) {
        mask = mask/2;
        result++;
    }
    return result;
}


int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("Usage: syscount <mask> <command> [args...]\n");
        exit(1);
    }

    int mask = atoi(argv[1]);  // Read the mask
    if (mask <= 0 || (mask & (mask - 1)) != 0) {
        printf("Error: Mask must be a power of 2\n");
        exit(1);
    }

    // Fork to run the command
    int pid = fork();
    if (pid == 0) {
        // Child process runs the command
        exec(argv[2], argv + 2);
        printf("exec failed\n");
        exit(1);
    } else if (pid < 0) {
        printf("fork failed\n");
        exit(1);
    }

    // Parent process waits for child to finish
    int status;
    wait(&status);

    // Now we retrieve the count
    int syscall_num = find_syscall_index(mask); // Get the index of the set bit
    int count = syscount(syscall_num); // Call the new syscall
    printf("PID %d called %s %d times.\n", pid, syscall_names[syscall_num-1], count);

    exit(0);
}
