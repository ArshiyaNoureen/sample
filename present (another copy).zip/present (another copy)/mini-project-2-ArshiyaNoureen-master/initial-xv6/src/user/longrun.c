#include "kernel/types.h"
#include "user/user.h"

int main() {
    while (1) {
        printf("Process %d is running\n", getpid());
        sleep(100);  // Sleep to avoid too much output
    }
    exit(0);
}
