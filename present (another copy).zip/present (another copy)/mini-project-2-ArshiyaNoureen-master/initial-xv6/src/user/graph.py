import matplotlib.pyplot as plt
import numpy as np

# Sample data, modify this as per your specific input
data = [
    (70, 4, 0), (70, 5, 0), (70, 6, 0), (70, 7, 0), (70, 8, 0), (70, 11, 1), (70, 13, 1), (70, 9, 1),
    (80, 4, 0), (80, 5, 0), (80, 6, 0), (80, 7, 0), (80, 8, 0), (80, 11, 1), (80, 13, 1), (80, 9, 1),
    (90, 4, 0), (90, 5, 0), (90, 6, 0), (90, 7, 0),
    (100, 4, 0), (100, 5, 0), (100, 6, 0), (100, 7, 0), (100, 8, 0), (100, 10, 1), (100, 11, 1),
    (110, 4, 0), (110, 5, 0), (110, 6, 0), (110, 7, 0), (110, 8, 0), (110, 10, 1), (110, 11, 1),
    (120, 4, 0), (120, 5, 0), (120, 6, 0), (120, 7, 0), (120, 8, 0), (120, 10, 1), (120, 11, 1),
    (130, 4, 0), (130, 5, 0), (130, 6, 0), (130, 7, 0), (130, 8, 0), (130, 10, 1), (130, 11, 1),
    (140, 4, 0), (140, 5, 0), (140, 6, 0), (140, 7, 0), (140, 8, 0), (140, 10, 1), (140, 11, 1),
    (150, 4, 0), (150, 5, 0), (150, 6, 0), (150, 7, 0), (150, 8, 0), (150, 10, 1),
    (160, 4, 0), (160, 5, 0), (160, 6, 0), (160, 7, 0), (160, 8, 0),
    (170, 4, 0), (170, 5, 0), (170, 6, 0), (170, 7, 0), (170, 8, 0), (170, 10, 1),
    (180, 4, 0), (180, 5, 0), (180, 6, 0), (180, 7, 0), (180, 8, 0),
    (190, 4, 0), (190, 5, 0), (190, 6, 0), (190, 7, 0), (190, 8, 0),
    (200, 4, 0), (200, 5, 0), (200, 6, 0), (200, 7, 0), (200, 8, 0),
    (210, 4, 0), (210, 5, 0), (210, 6, 0), (210, 7, 0), (210, 8, 0)
]

# Convert data into x (time), y (queue_id), and color (process_id)
times = [entry[0] for entry in data]
queue_ids = [entry[2] for entry in data]
process_ids = [entry[1] for entry in data]

# Generate the plot
plt.figure(figsize=(12, 8))

# Scatter plot for each process, color by process_id
scatter = plt.scatter(times, queue_ids, c=process_ids, cmap='tab20', s=100, edgecolors="black", alpha=0.7)

# Label each point with offsets to prevent overlap
for i, txt in enumerate(process_ids):
    # Adding small offsets to avoid overlap
    x_offset = np.random.uniform(-3, 3)  # Random small offset for x-coordinate
    y_offset = np.random.uniform(-3, 3)  # Random small offset for y-coordinate
    plt.text(times[i] + x_offset, queue_ids[i] + y_offset, f'P{txt}', fontsize=8, ha='center', va='center', color='black', fontweight='bold')

# Customize the plot
plt.xlabel("Time (ms)")
plt.ylabel("Queue ID")
plt.title("Process Timeline with Queue ID Over Time")

# Add a colorbar to show Process ID mapping
cbar = plt.colorbar(scatter, label='Process ID')

# Add grid and labels for clarity
plt.grid(True)
plt.tight_layout()

# Show the plot
plt.show()
