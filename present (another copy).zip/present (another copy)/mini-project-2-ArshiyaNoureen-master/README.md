# REPORT AND ASSSUMPTIONS

## QUESTION1

**1. What is the implication of adding the arrival time in the lottery based scheduling policy?**

In a lottery-based scheduling policy, adding arrival time ensures that processes which arrived earlier are more likely to be chosen, even if they have the same number of tickets as newer processes. This doesn't directly prioritize based on how long a process has waited but uses arrival time as a factor to enhance fairness. The challenge here is that balancing both tickets and arrival time increases the complexity of the scheduling logic. If all processes have the same number of tickets, the lottery becomes random, potentially leading to unfair outcomes where newly arrived processes could disrupt older ones despite their earlier arrival.


**2. Are there any pitfalls to watch out for?**
Yes, there are a few pitfalls to watch out for when adding arrival time to the lottery-based scheduling policy:

    Increased Complexity: The scheduler now needs to manage both the number of tickets and arrival times, which can make the implementation more complex and may introduce overhead in terms of computation and memory usage.

    Inconsistent Fairness: While considering arrival time improves fairness for older processes, there’s still a chance that newer processes with many tickets could dominate the lottery, causing longer delays for older processes with fewer tickets.

    Randomness Issues: If all processes have the same number of tickets and arrival times are close together, the random selection may still result in unfair execution, where some processes get repeatedly chosen while others wait for longer periods.

**3.What happens if all processes have the same number of tickets?**

If all processes have the same number of tickets in a lottery-based scheduling policy, the selection becomes entirely random. Since each process has an equal chance of being chosen, this randomness can lead to inconsistent and potentially unfair scheduling outcomes. Specifically:

    Unpredictable Wait Times: Some processes might get selected multiple times in a row purely by chance, while others may have to wait much longer, even though they have the same priority.

    Unfair Execution Order: Newer processes could be chosen before older ones, disrupting fairness, especially if the arrival time is not taken into account properly.

This random nature can create a situation where fairness isn't guaranteed, even when all processes have an equal number of tickets.



## QUESTION2

### Round Robin (RR) Scheduling:
#### Average running time (rtime)
55, 78, 71, 76, 72
Average: (55 + 78 + 71 + 76 + 72) / 5 = 70.4

#### Average waiting time (wtime)
160, 177, 168, 177, 168
Average: (160 + 177 + 168 + 177 + 168) / 5 = 170

### Lottery-Based Scheduling (LBS):
#### Average running time (rtime)
107, 68, 30, 26, 25
Average: (107 + 68 + 30 + 26 + 25) / 5 = 51.2

#### Average waiting time (wtime)
199, 199, 185, 183, 184
Average: (199 + 199 + 185 + 183 + 184) / 5 = 190

### Observations:
#### Running Time (rtime):
**Round Robin:** Average rtime is 70.4, which is higher than LBS (51.2).
**LBS:** LBS shows more variability in rtime (from 107 to 25), while RR is more consistent, ranging between 55 and 78.
**Reason:** Round Robin gives each process a fixed time slice, ensuring fairness and predictable CPU time. LBS, being probabilistic, leads to inconsistent CPU allocation, as some processes can randomly be picked frequently, reducing their rtime, while others may wait longer.

#### Waiting Time (wtime):
**Round Robin:** The average wtime is 170, which is lower than LBS's 190.
**LBS:** LBS has a higher and more variable wtime (ranging from 183 to 199).
**Reason:** In Round Robin, processes are served in a regular, cyclic manner, which balances the wait times. In LBS, processes with fewer tickets might get picked less frequently, causing them to wait longer. The randomness in LBS leads to some processes waiting much longer than others, increasing the average waiting time.

### Explanation of the Differences:

#### Fairness:
        Round Robin is designed for fairness, giving each process an equal opportunity to run. This reduces extreme cases of starvation or very long waiting times.
        LBS, due to its randomness, can sometimes favor certain processes more than others, leading to unfairness in terms of who gets CPU time. This explains why some processes in LBS have shorter running times (due to frequent CPU access) and others have long waiting times (due to not being selected frequently).

#### Variability in LBS:
        The random selection in LBS is what causes the variability in both rtime and wtime. Processes with more tickets are likely to be picked more often, but since the selection is not deterministic, the distribution of CPU time can be inconsistent, leading to large variations in running and waiting times.

#### Round Robin Consistency:
        Round Robin’s consistency in terms of rtime and wtime stems from its systematic, time-slice-based allocation of CPU time. Each process is guaranteed a turn after a fixed period, which minimizes variability in performance metrics.



## SPECIFICATION EXPLANATIONS

### Gotta count 'em all

I added a new system call getSysCount to the xv6 operating system, which allows processes to retrieve the count of a specific system call that has been invoked. The implementation involves several key components:

The proc structure was modified to include an array syscall_counts[32] to track the counts of up to 32 system calls.

In the syscall function, the syscall number is obtained from the trap frame, and the count for the corresponding syscall is incremented in the current process's syscall_counts array before invoking the actual syscall handler.

The sys_getSysCount function retrieves the count of the specified syscall number passed from the user program. It validates the syscall number and returns the count from the current process's syscall_counts array.

Additionally, I modified the wait function to ensure that when a child process exits, its syscall counts are added to the parent's counts. This is done through a loop that iterates through the syscall counts of the child and accumulates them into the parent's syscall_counts.

These modifications enable the syscount user program, which accepts a bitmask representing a specific syscall and counts how many times that syscall has been called during the execution of another command. The syscall count is printed in a formatted message after the command completes, including the PID of the calling process and the name of the syscall.


### Wake me up when my timer ends
I implemented two new system calls in XV6: sigalarm and sigreturn, providing user-level signal handling. This allows a process to set an alarm that triggers after a specific number of CPU ticks, running a handler function. In the process structure, I added fields to track the alarm interval, CPU tick count, the handler function, and backup the trapframe before entering the handler.

The system calls were defined in syscall.h and mapped in syscall.c. The sys_sigalarm system call sets the alarm interval and handler, while sys_sigreturn restores the process state from the saved trapframe after the handler finishes these are defined in sysproc.c.

In the trap handler, I modified usertrap to check for an alarm on each timer interrupt. When the alarm condition is met, the process's trapframe is saved, and execution jumps to the handler. The process continues where it left off once the handler finishes by calling sigreturn.

I also updated the user interface in user.h and usys.pl for these system calls, and modified the Makefile to include the alarmtest program, ensuring it compiles and runs correctly. This implementation enables user-level periodic actions without disrupting normal process execution


### LBS
A new integer variable tickets is added to the struct proc in proc.h to track the number of lottery tickets each process holds. The settickets system call is implemented to allow a process to modify its own ticket count dynamically. Each process is initialized with 1 ticket in the allocproc function within proc.c, ensuring all processes have a default number of tickets when created.

In the scheduling logic, if the SCHEDULER=LBS is defined, the total number of tickets from all runnable processes is calculated by iterating through the process table. After determining the total tickets, a winning ticket is randomly selected. The scheduler then iterates through the runnable processes again, adding up the tickets until it finds the process that holds the winning ticket. This process is selected to run.

To handle cases where multiple processes have the same number of tickets, an additional check is performed to find the process that arrived earlier, ensuring fairness. Once the winning process is selected, the scheduler locks the process, switches its state to RUNNING, and performs a context switch to allow the chosen process to execute. After the process has finished its turn, it is returned to the RUNNABLE state, and the scheduler repeats the process for the next scheduling 

### Assumptions

1. In my implementation the option to replay is given to both clients together and not one after another
2. The player who doesnot have a turn makes a move i kept the turn made in the buffer rather than printing error message
